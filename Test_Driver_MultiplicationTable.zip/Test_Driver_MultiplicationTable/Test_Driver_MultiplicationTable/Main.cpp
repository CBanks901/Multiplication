// this main method is to test the MultiplicationTable class

#include "MultiplicationTable.h"

int main(void)
{
	MultiplicationTable Game;
	Game.Play();

	return 0;
}