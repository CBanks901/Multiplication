// MultiplicationTable definitions
#pragma once

#include <iostream>
#include <time.h>
#include "MultiplicationTable.h"

using namespace std;


// constructor
MultiplicationTable::MultiplicationTable()
{
	this->mFirstNum = 0;
	this->mSecondNum = 0;
	this->mAnswer = 0;
	this->mRedScore = 0;
	this->mBlueScore = 0;
	this->mTurn = RED; // start with RED team

	// set eTurn Team to RED

	//fill array with zeros
	for(int i = 0; i < 10; ++i)
	{
		for(int j = 0; j < 10; ++j)
		{
			mEquationArray[i][j] = 0;
		}	
	}

}

//destructor
MultiplicationTable::~MultiplicationTable()
{
	
}

// set equation
void MultiplicationTable::SetEquation()
{
	bool repeated = false;
	// check for repeated equation
	while(!repeated)
	{
		srand(time(NULL)); // seed RNG
		mFirstNum = ( rand() % 10 ) + 1; // make sure 1 - 10
		mSecondNum = ( rand() % 10 ) + 1;// make sure 1 - 10
/* possible if statement here to check whether mfirst == msecond, if true, update array*/
		repeated = RepeatedEquation();

		//update array if not repeated
		mEquationArray[mFirstNum-1][mSecondNum-1] = 1;
	}
}

// get first number
int MultiplicationTable::GetFirstNum()
{
	return mFirstNum;
}

// get second number
int MultiplicationTable::GetSecondNum()
{
	return mSecondNum;
}

// check for correct user answer
bool MultiplicationTable::IsCorrect()
{
	return mAnswer == mFirstNum * mSecondNum;
}

// check to see if equation is repeated 
bool MultiplicationTable::RepeatedEquation()
{
	return mEquationArray[mFirstNum-1][mSecondNum-1] == 1;
}

// Display the equation and get input
void MultiplicationTable::DisplayEquation()
{
	cout << mFirstNum << " X " << mSecondNum << " ";
	cin >> mAnswer;
}

// Display team scores
void MultiplicationTable::DisplayScore()
{
	cout << "RED: " << mRedScore << " \t\t\t " << "BLUE: " << mBlueScore << endl;
}

int MultiplicationTable::WhichTeamTurnIsIt()
{
	return mTurn;
}

bool MultiplicationTable::TestForWin()
{
	if(mRedScore == 10)
	{
		cout << "RED TEAM WINS";
		cin.get(); //hold console window open
		return true;
	}
	if(mBlueScore == 10)
	{
		cout << "BLUE TEAM WINS";
		cin.get();
		return true;
	}
	else { return false; }
}

void MultiplicationTable::RecursivelyGetInputUntilCorrect()
{
	if(WhichTeamTurnIsIt() == RED)
	{
	//check if correct
		if(IsCorrect())
		{
			cout << "GOOD JOB! RED TEAM!\n\n";
			mTurn = BLUE;
			mRedScore++;	
		}
		else
		{
			cout << "Sorry Incorrect.\n\n";
			mTurn = BLUE;
			cout << "It is BLUE Teams turn\n";
			DisplayEquation();
			RecursivelyGetInputUntilCorrect();
		}

	}
	else if(WhichTeamTurnIsIt() == BLUE)
	{
	//check if correct
		if(IsCorrect())
		{
			cout << "GOOD JOB! BLUE TEAM!\n\n";
			mTurn = RED;
			mBlueScore++;	
		}
		else
		{
			cout << "Sorry Incorrect.\n";
			mTurn = RED;
			cout << "It is RED Teams turn\n";
			DisplayEquation();
			RecursivelyGetInputUntilCorrect();
		}
	}
}
void MultiplicationTable::Play()
{
	while(!TestForWin())
{
	SetEquation();
	DisplayScore();
	if(WhichTeamTurnIsIt() == RED)
	{
		cout << "It is RED Teams Turn" << endl; 
	}
	else
	{
		cout << "It is BLUE Teams Turn" << endl;
	}	
	
	DisplayEquation();
	RecursivelyGetInputUntilCorrect();
	
			
} // end while
}