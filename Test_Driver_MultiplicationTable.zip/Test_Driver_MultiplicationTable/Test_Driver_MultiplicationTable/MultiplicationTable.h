// MultiplicationTable class header.


class MultiplicationTable{

	private:
		// ints to hold first and second number in equation and answer
		int mFirstNum, mSecondNum, mAnswer;
		// team scores 
		unsigned int mRedScore, mBlueScore;
		// which team turn is it?
		enum eTurn { RED, BLUE };
		int mTurn;
		// array to store value 0 or 1 to determine if an equation has been given
		int mEquationArray[10][10]; 
	public:
		// constructor
		MultiplicationTable();
		// destructor
		~MultiplicationTable();
		//Set Equation using rand()
		void SetEquation();
		//get mFirstNum
		int GetFirstNum();
		//get mSecondNum
		int GetSecondNum();
		//Returns true if user input mAnswer = mFirstNum x mSecondNum
		bool IsCorrect();
		//checks to see if equation was repeated checking equation array
		bool RepeatedEquation();
		//displays equation to the screen
		void DisplayEquation();
		//display team scores
		void DisplayScore();
		//returns which team turn it is enum eTurn
		int WhichTeamTurnIsIt();
		// tests for win if teamscore == 10 then display winner
		bool TestForWin();
		void RecursivelyGetInputUntilCorrect();
		void Play(); //plays the simulation
		// displays a tutorial
		void Tutorial();		
};